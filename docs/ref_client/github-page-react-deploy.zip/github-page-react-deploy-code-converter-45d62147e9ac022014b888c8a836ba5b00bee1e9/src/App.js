import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>---
        </p>
		<textarea></textarea>

		<select name="order" form="myForm">
			<option value="americano">아메리카노</option>
			<option value="caffe latte">카페라테</option>
			<option value="cafe au lait">카페오레</option>
			<option value="espresso">에스프레소</option>
		</select>
		<button>exec</button>
		<textarea></textarea>
      </header>
    </div>
  );
}

export default App;
